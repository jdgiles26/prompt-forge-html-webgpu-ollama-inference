"""Implementation lives here. Currently RED."""

def count_tokens(path: str) -> dict:
    raise NotImplementedError("implement count_tokens — see CLAUDE.md")

def main(argv=None):
    raise NotImplementedError("implement CLI entrypoint")

if __name__ == "__main__":
    import sys
    main(sys.argv[1:])